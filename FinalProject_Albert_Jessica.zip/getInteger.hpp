
#include <sstream>
#include <string>
#include <iostream>

int getInteger();
int getInteger(int, int);
bool isInteger(const std::string&);
 
